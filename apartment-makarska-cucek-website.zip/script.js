
function switchLanguage(lang) {
  document.querySelectorAll('.lang-hr').forEach(el => el.classList.toggle('hidden', lang !== 'hr'));
  document.querySelectorAll('.lang-en').forEach(el => el.classList.toggle('hidden', lang !== 'en'));
}
